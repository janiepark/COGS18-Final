from food import food_type

restaurants = food_type('meal')

print(restaurants)

greeting = input('tell me what the fuck is up kyle!')


print('Kyle said: ' + greeting)

