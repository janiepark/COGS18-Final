#First importing all the necessary methods and modules.
import random
from food_module import * #food_type, check_type, dietary_restriction, check_restriction, final_rec, check_rec

#Adding a narrative to ask the user in a user-friendly way what type of food they would like from the given options.
user_input = input('Let\'s find something for you to eat today!\nPlease enter what type of food you ' \
                    'would like to eat from the three options of "snack", "meal" or "drink": ')


while True:
    if str.lower(user_input) in ('snack','meal','drink'):
        break
    else:
        user_input = input("Sorry, we don't have that option. Please start over and choose one of the " \
                           "available options. ")
    
        
#The first method to choose which type of food the user would like.
type_of_food = food_type(str.lower(user_input))

#User friendly way to ask about their dietary restriction.
user_input = input("Thank you for choosing a type of food!\nOur next question is, do you happen to be " \
                   "vegetarian, vegan, gluten free or have a peanut allergy?\nIf so, please type 'vegetarian'," \
                   " 'vegan', 'gluten free' or 'peanut allergy'. If not, please type 'none': ")

#The next question is if the user has a dietary restriction.
restrictions = dietary_restriction(user_input, type_of_food)

while True:
    if str.lower(user_input) in ('vegetarian','vegan','gluten free', 'peanut allergy', 'none'):
        
        break
        
    else:
        user_input = input("Sorry, we could not recognize what you said or currently do not have a " \
                           "comprehensive list for that dietary restriction. Please select one of the " \
                           "available options previously mentioned. ")

#Chooses a final vendor and gives information about it.
print(final_rec(restrictions))

user_input = input("Thank you for using our service! If you're not satisfied with your choice, " \
               "would you like to choose a new one? If so, type 'yes'. If no, type 'no': ")
while True:

    if str.lower(user_input) == ('no'):
        print('Hope you enjoy!')
        
        break
        
    elif str.lower(user_input) == ('yes'):
        
        print(final_rec(restrictions))
        
        user_input = input("Thank you for using our service! If you're not satisfied with your choice, " \
                       "would you like to choose a new one? If so, type 'yes'. If no, type 'no': ")
        
    else:
        user_input = input("Sorry, could not recognize what you typed. Based upon the previous " \
                           "question, please answer 'yes' or 'no': ")






