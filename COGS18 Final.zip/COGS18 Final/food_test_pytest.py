import pytest


def test_food_type():
    
    snacks = food_type('snack')
    
    assert snacks == [, , , ,]